#include <iostream>
#include <cstdlib>

using namespace std;

int main(){
	double a = -5;
	double b = (a* -1);
	cout << a << endl;
	cout << b << endl;

	return 0;
}
